﻿using Sprechstunden;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace TestProjectSprechstunden
{
    
    
    /// <summary>
    ///This is a test class for ProgramTest and is intended
    ///to contain all ProgramTest Unit Tests
    ///</summary>
    [TestClass()]
    public class ProgramTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        [TestMethod()]
        public void T01_IsSelectedSimple()
        {
            string name = "Hallo";
            string selection = "a";
            Assert.IsTrue(Program.IsSelected(name, selection));
        }

        [TestMethod()]
        public void T02_IsSelectedSimpleNotIn()
        {
            string name = "Hallo";
            string selection = "x";
            Assert.IsFalse(Program.IsSelected(name, selection));
        }

        [TestMethod()]
        public void T03_UpperCase()
        {
            string name = "HALLO";
            string selection = "a";
            Assert.IsTrue(Program.IsSelected(name, selection));
        }

        [TestMethod()]
        public void T04_EmptyName()
        {
            string name = "";
            string selection = "a";
            Assert.IsFalse(Program.IsSelected(name, selection));
        }

        [TestMethod()]
        public void T05_EmptySelection()
        {
            string name = "Hallo";
            string selection = "";
            Assert.IsTrue(Program.IsSelected(name, selection));
            name = "";
            Assert.IsTrue(Program.IsSelected(name, selection));
        }

        [TestMethod()]
        public void T06_AllLetters()
        {
            string name = "Hallo";
            string selection = "olah";
            Assert.IsTrue(Program.IsSelected(name, selection));
        }

        [TestMethod()]
        public void T07_SomeLettersTwice()
        {
            string name = "Hallo";
            string selection = "llaahh";
            Assert.IsTrue(Program.IsSelected(name, selection));
        }

    }
}
