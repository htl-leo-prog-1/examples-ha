using System;
using System.IO;
using System.Text;

namespace Sprechstunden
{
    public struct Teacher
    {
        public string Name;
        public string Title;
        public string Day;
        public string Time;
        public string Room;
    }

    public struct RoomStat
    {
        public string Room;
        public int Cnt;
    }


    /// <summary>
	/// Die csv-Datei Sprechstunden.csv wird nach Angaben des Benutzers
    /// nach der Klasse gefiltert. Das Ergebnis wird auf den 
    /// Bildschirm ausgegeben.
	/// </summary>
    public class Program
	{
		static void Main(string[] args)
		{
            Teacher[] allTeachers;
            Teacher[] selectedTeachers;
            string selectedLetters;

            Console.WindowWidth = 120;
            Console.Title = "Sprechstundenliste der HTL-Leonding";
            Console.WriteLine("Sprechstundenliste der HTL-Leonding");
            Console.WriteLine("===================================");
            allTeachers = ReadTeachersFromFile();
            Console.WriteLine("{0} Sprechstundens�tze eingelesen: ", allTeachers.Length);
            ShowTeachers(allTeachers);
            Console.WriteLine();
            Console.Write("Buchstaben [a-z] die enthalten sein m�ssen (leere Eingabe f�r Ende): ");
            selectedLetters = Console.ReadLine();
            Console.WriteLine();
            while (selectedLetters.Length > 0)
            {
                if (selectedLetters == "!")
                {
                    RoomStatistic(allTeachers);
                }
                else
                {
                    selectedTeachers = SelectTeachers(allTeachers, selectedLetters);
                    ShowTeachers(selectedTeachers);
                }
                Console.WriteLine();
                Console.Write("Buchstaben [a-z] die enthalten sein m�ssen (leere Eingabe f�r Ende): ");
                selectedLetters = Console.ReadLine();
                Console.WriteLine();
            }
		}

        /// <summary>
        /// Die Lehrer werden ausgew�hlt und zur�ckgegeben.
        /// Gro�/Kleinschreibung wird dabei nicht beachtet.
        /// </summary>
        /// <param name="teachers">alle lehrer</param>
        /// <param name="selectedLetters">Buchstaben, die enthalten sein m�ssen</param>
        /// <returns>gew�hlte Sprechstundens�tze</returns>
        private static Teacher[] SelectTeachers(Teacher[] teachers, string selectedLetters)
        {
            Teacher[] selectedTeachers;
            Teacher teacher;
            int countSelectedTeachers = 0;
            for (int i = 0; i < teachers.Length; i++)
            {
                teacher = teachers[i];
                if (IsSelected(teachers[i].Name, selectedLetters))
                {
                    countSelectedTeachers++;
                }
            }
            selectedTeachers = new Teacher[countSelectedTeachers];
            countSelectedTeachers = 0;
            for (int i = 0; i < teachers.Length; i++)
            {
                teacher = teachers[i];
                if (IsSelected(teachers[i].Name, selectedLetters))
                {
                    selectedTeachers[countSelectedTeachers] = teacher;
                    countSelectedTeachers++;
                }
            }
            return selectedTeachers;
        }

        /// <summary>
        /// �berpr�ft, ob der Lehrer die Selektionskriterien erf�llt.
        /// </summary>
        /// <param name="teacher">Zu pr�fender Lehrer</param>
        /// <param name="selectedLetters">Buchstaben, die enthalten sein m�ssen</param>
        /// <returns></returns>
        public static bool IsSelected(string name, string selectedLetters)
        {
            bool found = false;
            string lowerCaseName = name.ToLower();
            string lowerCaseSelection = selectedLetters.ToLower();
            for (int indexSelection = 0; indexSelection < lowerCaseSelection.Length; indexSelection++)
            {
                found = false;
                for (int indexLetter = 0; indexLetter < lowerCaseName.Length && !found; indexLetter++)
                {
                    found = (lowerCaseName[indexLetter] == lowerCaseSelection[indexSelection]);
                }
                if (!found)  // ein Buchstabe wurde nicht gefunden
                {
                    return false;
                }
            }
            return true; // alle Buchstaben wurden gefunden
        }

        /// <summary>
        /// Sprechstundenliste auf den Bildschirm ausgeben.
        /// </summary>
        private static void ShowTeachers(Teacher[] teachers)
        {
            Teacher teacher;
            if (teachers.Length > 0)
            {
                Console.WriteLine("{0,-25} {1,-3} {2,-14} {3,-5}", "Name", "Tag", "Zeit", "Raum");
                for (int i = 0; i < teachers.Length; i++)
                {
                    teacher = teachers[i];
                    Console.WriteLine("{0,-25} {1,-3} {2,-14} {3,-5}", teacher.Name,
                            teacher.Day, teacher.Time, teacher.Room);
                }
            }
            else
            {
                Console.WriteLine("Keine Daten verf�gbar!");
            }
        }

        /// <summary>
        /// Sprechstundendaten aus der csv-Datei in ein Array of Projekt einlesen.
        /// </summary>
        /// <returns>Neu angelegtes Sprechstundenarray</returns>
        static Teacher[] ReadTeachersFromFile()
        {
            string[] lines = File.ReadAllLines("Sprechstunden.csv", Encoding.Default);
            Teacher[] teachers = new Teacher[lines.Length - 1];
            for (int index = 1; index < lines.Length; index++)
            {
                string[] elemente = lines[index].Split(';');
                teachers[index - 1].Name = elemente[0];
                teachers[index-1].Day= elemente[4];
                teachers[index-1].Time= elemente[5];
                teachers[index-1].Room = elemente[6];
            }
            return teachers;
        }

        /// <summary>
        /// Sortiert die R�ume nach der Anzahl der Personen (absteigend mit Insertion-Sort)
        /// </summary>
        /// <param name="rooms"></param>
        static void OrderRooms(RoomStat[] rooms)
        {
            RoomStat temp;
            int actPos;
            for (int i = 1; i < rooms.Length; i++)
            {
                temp = rooms[i];
                actPos = i - 1;
                while (actPos >= 0 && rooms[actPos].Cnt < temp.Cnt)
                {
                    rooms[actPos + 1] = rooms[actPos];
                    actPos--;
                }
                rooms[actPos + 1] = temp;
            }
        }

        /// <summary>
        /// Erstellt ein Array je einem Eintrag je vorkommenden Raum und der Anzahl, wie oft dieser Raum
        /// vorkommt. 
        /// </summary>
        /// <param name="teachers"></param>
        /// <returns></returns>
        static RoomStat[] BuildRooms(Teacher[] teachers)
        {
            RoomStat[] rooms = new RoomStat[teachers.Length];
            int cntRooms = 0;
            bool found;
            for (int i = 0; i < teachers.Length; i++) //Alle Sprechstundeneintr�ge durchsuchen
            {
                int actPos = 0;
                found = false;
                while ((actPos < cntRooms) && (!found))
                {
                    if (rooms[actPos].Room == teachers[i].Room)
                        found = true;
                    else
                        actPos++;
                }
                if (!found)
                {
                    rooms[cntRooms].Room = teachers[i].Room;
                    rooms[cntRooms].Cnt = 1;
                    cntRooms++;
                }
                else
                {
                    rooms[actPos].Cnt++;
                }
            }

            //Array der richtigen Gr��e anlegen
            RoomStat[] newRooms = new RoomStat[cntRooms];
            for (int i = 0; i < cntRooms; i++) //Umkopieren
            {
                newRooms[i] = rooms[i];
            }

            return newRooms;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="teachers"></param>
        static void RoomStatistic(Teacher[] teachers)
        {
            RoomStat[] rooms = BuildRooms(teachers);
            OrderRooms(rooms);
            ShowRooms(rooms);
        }

        /// <summary>
        /// Gibt die Raumstatistik aus
        /// </summary>
        /// <param name="rooms"></param>
        private static void ShowRooms(RoomStat[] rooms)
        {
            Console.WriteLine("Raumstatistik:");
            Console.WriteLine("--------------");
            Console.WriteLine("{0,-7} {1,2}","Raum","Lehrer");
            for (int i = 0; i < rooms.Length; i++)
            {
                Console.WriteLine("{0,-7} {1,2}", rooms[i].Room, rooms[i].Cnt); 
            }
        }

	}
}
