import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EnemyFish here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnemyFish extends Actor
{
    /**
     * Act - do whatever the EnemyFish wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        move(3);
        int rz = 20-Greenfoot.getRandomNumber(41);
        turn(rz);
    }    
}
