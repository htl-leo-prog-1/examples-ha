import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PlayerFish here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PlayerFish extends Actor
{
    Bubble fishBubble=new Bubble();
    /**
     * Act - do whatever the PlayerFish wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.      
        move(2);
        if (Greenfoot.isKeyDown("a"))
        {
            turn(-3);
        }
        else if (Greenfoot.isKeyDown("s"))
        {
            turn(3);
        }
        else if (Greenfoot.isKeyDown(" "))
        {
            if (fishBubble.getWorld()==null)
            {
                fishBubble.setRotation(this.getRotation());
                getWorld().addObject(fishBubble, this.getX(), this.getY());
            }
        }
        
        if  ((getWorld()!=null) &&  (isTouching(EnemyFish.class)))
        {
            //Feindlichen Fish berührt => Ende des Spielers
            getWorld().removeObject(this);
        }    
        
    }    
}
