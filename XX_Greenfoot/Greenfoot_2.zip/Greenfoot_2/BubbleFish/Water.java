import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.*;

/**
 * Write a description of class Water here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Water extends World
{

    int count=0;
    int points;
    
    /**
     * Constructor for objects of class Water.
     * 
     */
    public Water()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        
        //Place Player Fish
        addObject(new PlayerFish(), 100, 300);     
    }
    
    public void act() 
    {
        
        //Punkte ausgeben
        this.getBackground().setColor(Color.BLACK); //import java.awt.*;
        this.getBackground().fillRect(300, 0, 100, 20); 
        this.getBackground().setColor(Color.WHITE); //import java.awt.*;
        String out="Punkte:"+points;
        this.getBackground().drawString(out, 305, 10);
       
        points++;
              
        if (count%200==0)
        {
          addObject(new EnemyFish(),50,50);
        }
          
        count++;
        
        if (getObjects(PlayerFish.class).size()==0)
        {
            Greenfoot.stop();
        }
    }  

}
