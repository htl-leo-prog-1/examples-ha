import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bubble here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bubble extends Actor
{
    /**
     * Act - do whatever the Bubble wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        move(5);
        if ((this.getX()>=getWorld().getWidth()-10) || (this.getX()<=10) || (this.getY()<=10) ||
            (this.getY()>=getWorld().getHeight()-10))
        {
            getWorld().removeObject(this);    
        }
        
        if (getWorld()!=null) //removeTouching darf nur aufgerufen werden, wenn Bubble in Welt platziert ist!
        {
            removeTouching(EnemyFish.class);
        }
    }    
}
