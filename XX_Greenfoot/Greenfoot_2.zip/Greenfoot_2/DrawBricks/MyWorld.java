import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import javax.swing.JOptionPane;
/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
       
        int row = Integer.parseInt( JOptionPane.showInputDialog("Wieviele Reihen?"));
        int columns = Integer.parseInt( JOptionPane.showInputDialog("Wieviele Spalten?"));
        for (int i = 1; i<=row; i++)
            {
              for (int v = 1; v<=columns; v++)
              {
                 addObject(new Brick(),v*50,i*20);
              }
            }
    }
}
