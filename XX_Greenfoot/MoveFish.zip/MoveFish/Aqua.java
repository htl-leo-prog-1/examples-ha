import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Aqua here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Aqua extends World
{

    /**
     * Constructor for objects of class Aqua.
     * 
     */
    public Aqua()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
       
        addObject(new Fish(), 60,60);
    }
}
