﻿using CarExample.Logic;
using System;

namespace CarExample.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Car myBMW = new Car(4);

            for (int i = 0; i < 5; i++)
            {
                if (!myBMW.EnterPerson(new Person("Walter")))
                    Console.WriteLine("Auto leider voll!");
                else
                    Console.WriteLine("Passagier "+(i+1)+" eingestiegen!");
            }
            
            
            //Person[] persons = new Person[17000];

            //for (int i = 0; i < persons.Length; i++)
            //{
            //    persons[i] = new Person();
            //}



        }
    }
}
