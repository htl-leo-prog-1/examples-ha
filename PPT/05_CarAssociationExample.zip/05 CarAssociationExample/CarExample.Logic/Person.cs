﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarExample.Logic
{
    public class Person
    {
		private string _name;

		public Person(string name)
		{
			_name = name;
		}

		public string Name
		{
			get { return _name; }
			set { _name = value; }
		}

	}
}
