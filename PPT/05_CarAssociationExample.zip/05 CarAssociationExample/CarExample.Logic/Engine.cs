﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarExample.Logic
{
    class Engine
    {
		private double _kw;

		public double Kw
		{
			get { return _kw; }
			set { _kw = value; }
		}

	}
}
