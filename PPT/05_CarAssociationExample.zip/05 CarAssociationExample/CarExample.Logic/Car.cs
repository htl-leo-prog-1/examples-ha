﻿using System;

namespace CarExample.Logic
{
    public class Car
    {
		private int _actIdx = 0;
		private string _type;

		public string Type
		{
			get { return _type; }
			set { _type = value; }
		}

		private Engine _engine;

		public bool EnterPerson(Person person)
		{
			if (_actIdx < _passengers.Length)
			{
				_passengers[_actIdx] = person;
				_actIdx++;
				return true;
			}
			else
			{
				return false;
			}
		}

		private Person[] _passengers;

		public Person[] Passengers
		{
			get
			{
				return _passengers;
			}
		}

		public Car(int maxPassengers)
		{
			_passengers = new Person[maxPassengers];
			_engine = new Engine();
		}
	}
}
