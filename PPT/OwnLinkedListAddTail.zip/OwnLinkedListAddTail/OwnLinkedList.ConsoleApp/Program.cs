﻿using OwnLinkedList.Core;
using System;

namespace OwnLinkedList.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            PupilList list = new PupilList();
            list.Add(new Pupil() { LastName = "Mustermann" });
            list.Add(new Pupil() { LastName = "Huber" });
            list.Add(new Pupil() { LastName = "Maier" });

            for (int i = 0; i < list.Count; i++)
            {
                Console.WriteLine(list.GetAt(i).LastName);
            }


        }
    }
}
