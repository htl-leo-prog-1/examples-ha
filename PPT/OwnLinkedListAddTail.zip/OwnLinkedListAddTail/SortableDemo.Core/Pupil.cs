﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OwnLinkedList.Core
{
    public class Pupil
    {
		private string _firstName;

		public string FirstName
		{
			get { return _firstName; }
			set { _firstName = value; }
		}

		private string _lastName;

		public string LastName
		{
			get { return _lastName; }
			set { _lastName = value; }
		}

		private int _age;

		public int Age
		{
			get { return _age; }
			set { _age = value; }
		}



	}
}
