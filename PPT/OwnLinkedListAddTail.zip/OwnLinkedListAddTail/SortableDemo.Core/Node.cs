﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OwnLinkedList.Core
{
    public class Node
    {
        Pupil _pupil;

        Node _next;

        public Pupil Pupil
        {
            get
            {
                return _pupil;
            }
            set
            {
                _pupil = value;
            }
        }

        public Node Next
        {
            get
            {
                return _next;
            }
            set
            {
                _next = value;
            }
        }

        public Node(Pupil pupil)
        {
            _pupil = pupil;
        }
    }
}
