﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace OwnLinkedList.Core
{
    public class PupilList
    {
        Node _head;
        Node _tail;

        int _itemCount = 0;

        public PupilList()
        {

        }


        /// <summary>
        /// Fügt neue Elemente am Ende der Liste ein
        /// </summary>
        /// <param name="pupil"></param>
        public void Add(Pupil pupil)
        {
            Node newNode = new Node(pupil);
            if (_head == null) //Erstes Element
            {
                _head = newNode;
            }
            else
            {
                _tail.Next = newNode;
            }
            _tail = newNode;

            _itemCount++;
        }



        /// <summary>
        /// Inserts the element in the list at the specified index
        /// </summary>
        /// <param name="index"></param>
        /// <param name="item"></param>
        public void Insert(int index, Pupil pupil)
        {
            Node newNode = new Node(pupil);

            if (index == _itemCount - 1) //Wenn Element am Ende eingefügt wird, muß zusätzlich _tail umgesetzt werden
                _tail = newNode;

            if (index == 0)
            {
                newNode.Next = _head;
                _head = newNode;
                _itemCount++;
            }
            else
            {
                Node actNode = GetNodeAt(index - 1);
                if (actNode != null)
                {
                    newNode.Next = actNode.Next;
                    actNode.Next = newNode;
                    _itemCount++;
                }
            }



        }


        /// <summary>
        /// Removes the first occurrence of a specific object from the list
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public bool Remove(Pupil item)
        {
            int idx = 0;
            Node actNode = _head;
            while (actNode != null)
            {
                if (actNode.Pupil == item)
                {
                    RemoveAt(idx);
                    return true;
                }
                actNode = actNode.Next;
            }
            return false;
        }


        /// <summary>
        /// Removes the element at the specified index
        /// </summary>
        /// <param name="index"></param>
        public void RemoveAt(int index)
        {
            bool isRemovingTail = index == _itemCount - 1;
            if (index == 0)
            {
                if (_head != null)
                {
                    _head = _head.Next;
                    _itemCount--;
                    if (isRemovingTail)
                        _tail = _head;
                }
            }
            else
            {
                Node actNode = GetNodeAt(index - 1);
                if (actNode!=null)
                {
                    actNode.Next = actNode.Next.Next;
                    _itemCount--;
                    if (isRemovingTail)
                        _tail = actNode.Next;
                }
            }

            
        }

        /// <summary>
        /// returns element at the specified index 
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public Pupil GetAt(int index)
        {
            Node actNode = GetNodeAt(index);
            if (actNode != null)
                return actNode.Pupil;
            else
                return null;
        }

        private Node GetNodeAt(int index)
        {
            Node actNode = _head;
            if (index >= 0 && index < _itemCount)
            {
                for (int i = 0; i < index; i++)
                {
                    actNode = actNode.Next;
                }
                return actNode;
            }
            return null;
        }
        /// <summary>
        /// Sorts the elements in the entire list 
        /// Very expensive operation with linked list --> cheaper: Copy elemtents to ArrayList, sort that list and copy back to LinkedList
        /// </summary>
        public void Sort()
        {
            bool swapped;
            int i = 1;
            do
            {
                swapped = false;
                for (int u = 0; u < _itemCount - i; u++)
                {
                    if (GetAt(u).Age > GetAt(u + 1).Age)
                    {
                        Swap(u, u + 1);
                        swapped = true;
                    }
                }
            } while (swapped);
        }

        /// <summary>
        /// Helper method to swap two elements in the list
        /// </summary>
        /// <param name="idx1"></param>
        /// <param name="idx2"></param>
        private void Swap(int idx1, int idx2)
        {
            Pupil temp = GetNodeAt(idx1).Pupil;
            GetNodeAt(idx1).Pupil = GetNodeAt(idx2).Pupil;
            GetNodeAt(idx2).Pupil = temp;
        }



        /// <summary>
        /// Gets the number of elements in the list
        /// </summary>
        /// <returns></returns>
        public int Count
        {
            get
            {
                return _itemCount;
            }
        }

    }
}
