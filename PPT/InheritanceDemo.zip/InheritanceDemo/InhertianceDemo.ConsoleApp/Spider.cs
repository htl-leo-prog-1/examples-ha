﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InhertianceDemo.ConsoleApp
{
    class Spider : Animal
    {
        public Spider(string name) : base(name)
        {
        }
    }
}
