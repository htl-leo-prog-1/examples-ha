﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InhertianceDemo.ConsoleApp
{
    class Dog: Animal
    {
		public Dog(string name) : base(name)
		{
		}

		public string Bite()
		{
			return Name + " makes Grrrrrrr";
		}

		public override string MakeNoise()
		{
			return "Wuff";
		}

		public override string ToString()
		{
			return base.ToString() + " and a dog";
		}
	}
}
