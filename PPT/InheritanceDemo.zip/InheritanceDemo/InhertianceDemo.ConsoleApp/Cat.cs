﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InhertianceDemo.ConsoleApp
{
    class Cat: Animal
    {
        public Cat(string name): base(name)
        {
        }

        public override string MakeNoise()
        {
            return "Miau";
        }

        public override string ToString()
        {
            return base.ToString()+"I am a cat!";
        }
    }
}
