﻿using System;
using System.Collections.Generic;

namespace InhertianceDemo.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Cat cat1 = new Cat("Minka");

            Dog dog1 = new Dog("Rantanplan");

            Spider spider1 = new Spider("Itsibitsi");

            //Console.WriteLine(cat1.MakeNoise());
            //Console.WriteLine(dog1.MakeNoise());

            ////Polymorphie
            //Animal a1 = cat1;
            //Animal a2 = dog1;

            Animal[] animals = new Animal[3];
            animals[0] = cat1;
            animals[1] = dog1;
            animals[2] = spider1;

            for (int i = 0; i < animals.Length; i++)
            {
                Console.WriteLine(animals[i].MakeNoise());     
            }

            object o = new List<int>();
            o = cat1;
            o = dog1;
            Console.WriteLine(o.ToString());
            Console.WriteLine(o);
        }
    }
}
