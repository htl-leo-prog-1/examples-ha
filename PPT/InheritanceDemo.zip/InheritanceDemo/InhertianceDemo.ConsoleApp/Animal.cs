﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InhertianceDemo.ConsoleApp
{
    class Animal
    {
		private string _name;

		public string Name
		{
			get { return _name; }
			set { _name = value; }
		}

		public virtual string MakeNoise()
		{
			return "";
		}

		public Animal(string name)
		{
			_name = name;
		}

		public override string ToString()
		{
			return "i am a animal";
		}
	}
}
