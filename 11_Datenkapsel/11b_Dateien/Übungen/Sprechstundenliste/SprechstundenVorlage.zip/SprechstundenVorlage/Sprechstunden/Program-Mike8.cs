using System;
using System.IO;
using System.Text;

namespace Sprechstunden
{
   

    /// <summary>
	/// Die csv-Datei Sprechstunden.csv wird nach Angaben des Benutzers
    /// nach der Klasse gefiltert. Das Ergebnis wird auf den 
    /// Bildschirm ausgegeben.
	/// </summary>
    public class Program
	{
		static void Main(string[] args)
		{
            Console.WindowWidth = 120;
            Console.Title = "Sprechstundenliste der HTL-Leonding";
            Console.WriteLine("Sprechstundenliste der HTL-Leonding");
            Console.WriteLine("===================================");
		}

      
        /// <summary>
        /// �berpr�ft, ob der Lehrer die Selektionskriterien erf�llt.
        /// </summary>
        /// <param name="teacher">Zu pr�fender Lehrer</param>
        /// <param name="selectedLetters">Buchstaben, die enthalten sein m�ssen</param>
        /// <returns></returns>
        public static bool IsSelected(string name, string selectedLetters)
        {
           
            return false; 
        }
	}
}
