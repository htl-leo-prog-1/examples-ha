﻿using System;
using System.Text;
using System.IO;

namespace CommentQuote
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Kommentarquote für c#-Datei");
            Console.WriteLine("===========================");

            string proceed = "j";

            do
            {
                string[] lines = ReadLinesFromFile();

                int sizeAllLetters = CountLettersAndDigits(lines);
                int sizeCommentLetters = CountComments(lines);
                double commentQuote = (double)sizeCommentLetters * 100.0 / sizeAllLetters;

                Console.WriteLine(
                    "Von {0} Zeichen waren {1} Kommentar, das ergibt {2:0.00}% Kommentarquote",
                     sizeAllLetters,
                     sizeCommentLetters,
                     commentQuote);

                Console.Write("Weiter ('j')?");
                proceed = Console.ReadLine();
            }
            while (proceed == "j");
        }

        /// <summary>
        /// Gültigen Dateinamen von der Konsole einlesen. Die Datei liegt
        /// im \bin\debug-Verzeichnis der Anwendung
        /// </summary>
        /// <returns>Alle Zeilen der gültigen cs-Datei als String-Array</returns>
        static string[] ReadLinesFromFile()
        {
            string fileName = "";
            do
            {
                Console.Write("Dateiname ohne Endung (im Anwendungsverzeichnis \\bin\\debug): ");
                fileName = Console.ReadLine();
                fileName += ".cs";
            } while (!File.Exists(fileName));

            return File.ReadAllLines(fileName);
        }

        /// <summary>
        /// Gesamtanzahl der zu zählenden Zeichen einlesen
        /// </summary>
        /// <param name="lines"></param>
        /// <returns>Anzahl von Buchstaben und Ziffern</returns>
        private static int CountLettersAndDigits(string[] lines)
        {
            int count = 0;
            for (int line = 0; line < lines.Length; line++)
            {
                for (int column = 0; column < lines[line].Length; column++)
                {
                    if (char.IsLetterOrDigit(lines[line][column]))
                    {
                        count++;
                    }
                }
            }
            return count;
        }

        /// <summary>
        /// Zählt die Kommentarzeichen (Buchstaben und Ziffern)
        /// </summary>
        /// <param name="lines"></param>
        /// <returns>Anzahl der Kommentarzeichen</returns>
        private static int CountComments(string[] lines)
        {
            bool inBlockComment = false;
            int count = 0;
            for (int lineNr = 0; lineNr < lines.Length; lineNr++)
            {
                count += CountCommentsInLine(lines[lineNr], ref inBlockComment);
            }
            return count;
        }

            /// <summary>
        /// Zählt die Kommentarzeichen (Buchstaben und Ziffern)
        /// </summary>
        /// <param name="lines"></param>
        /// <returns>Anzahl der Kommentarzeichen</returns>
        private static int CountCommentsInLine(string line, ref bool inBlockComment)
        {
            int count = 0;
            bool inLineComment = false;
            for (int column = 0; column < line.Length; column++)  // zeile abarbeiten
            {
                if (line[column] == '/' && line.Length > column + 1)  // eventuell Kommentarbeginn und es kommt noch ein Zeichen
                {
                    if (line[column + 1] == '/')  // Zeilenkommentar oder XML-Kommentar
                    {
                        inLineComment = true;
                    }
                    else
                    {
                        if (line[column + 1] == '*')
                        {
                            inBlockComment = true;
                        }
                    }
                }
                else  // Ende des Blockkommentars prüfen
                {
                    if (line[column] == '*' && line.Length > column + 1)  // eventuell Kommentarbeginn und es kommt noch ein Zeichen
                    {
                        if (line[column + 1] == '/')  // Ende des Blockkommentars
                        {
                            inBlockComment = false;
                        }
                    }
                }
                if ((inLineComment || inBlockComment) && char.IsLetterOrDigit(line[column]))
                {
                    count++;
                }
            }
            return count;
        }

    }
}
